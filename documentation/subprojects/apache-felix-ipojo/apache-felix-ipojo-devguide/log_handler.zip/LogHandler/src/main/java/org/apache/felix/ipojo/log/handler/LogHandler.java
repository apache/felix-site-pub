package org.apache.felix.ipojo.log.handler;


import java.util.Dictionary;

import org.apache.felix.ipojo.InstanceManager;
import org.apache.felix.ipojo.Handler;
import org.apache.felix.ipojo.metadata.Element;
import org.osgi.framework.BundleContext;
import org.osgi.framework.InvalidSyntaxException;
import org.osgi.framework.ServiceEvent;
import org.osgi.framework.ServiceListener;
import org.osgi.framework.ServiceReference;
import org.osgi.service.log.LogService;

public class LogHandler extends Handler implements ServiceListener {
	
	public static final String NAMESPACE = "org.apache.felix.ipojo.log.handler.LogHandler";
	
	private BundleContext context;
	private InstanceManager manager;
	
	private ServiceReference ref;
	private LogService log;
	private int level;
	
	
	/**
	 * to parse the metadata and get the logging level
	 * 
	 * @param cm
	 * @param metadata
	 * @param config
	 */
	public void configure(InstanceManager cm, Element metadata, Dictionary config) {
		// First parse the metadata to check if the log handler level
		
		// Get all Namespace:log element from the metadata
		Element[] log_elements = metadata.getElements("log", NAMESPACE);
		
		// if no element found, return 
		if(log_elements.length == 0) { return; } 
		else {
			// If an element match, parse the level attribute of the first founded element
			if(log_elements[0].containsAttribute("level")) {
				String l = log_elements[0].getAttribute("level");
				if(l.equalsIgnoreCase("info")) { level = LogService.LOG_INFO; }
				else if(l.equalsIgnoreCase("error")) { level = LogService.LOG_ERROR; }
				else if(l.equalsIgnoreCase("warning")) { level = LogService.LOG_WARNING; }
			}
			// Register on the component manager, to be a part of the component instance container
			manager = cm;
			manager.register(this);
			context = manager.getContext();  // To get the bundle context, ask to the component manager
		}
	}
	
	
	/**
	 * 
	 */
	public void start() {
		
		// When starting, look for an LogService
		ref = context.getServiceReference(LogService.class.getName());
		if(ref != null) { 
			log = (LogService) context.getService(ref);
			// Log the event
			log.log(level, "The component instance " + manager.getInstanceName() + " is starting");
		}
		// Registered a service listenner
		try {
			context.addServiceListener(this, "(OBJECTCLASS="+LogService.class.getName()+")");
		} catch (InvalidSyntaxException e) { e.printStackTrace(); }
	}
	
	
	/**
	 * 
	 */
	public void stop() {
		// Log the event, unget the service
		if(log != null) { log.log(level, "The component instance " + manager.getInstanceName() + " is stopping"); }	
		if(ref != null) { log = null; context.ungetService(ref); }
	}
	
	
	/**
	 * to be invalid when the Log Service is not available
	 * @return boolean
	 */
	public boolean isValid() {
		// The handler is valid <=> a log service is available
		return (ref != null);
	}
	
	
	/**
	 * to log the message
	 * @param state
	 */
	public void stateChanged(int state) {
		// log the state changed events
		if(log != null) {
			if(state == InstanceManager.VALID) { 
				System.out.println("The component instance " + manager.getInstanceName() + " becomes valid");
				log.log(level, "The component instance " + manager.getInstanceName() + " becomes valid"); }
			if(state == InstanceManager.INVALID) { 
				System.out.println("The component instance " + manager.getInstanceName() + " becomes invalid");
				log.log(level, "The component instance " + manager.getInstanceName() + " becomes invalid"); }
		}
	}

	
	/**
	 * To track the availability of the Log Service
	 */
	public void serviceChanged(ServiceEvent event) {
		// Check if the service event does not infers with the log service
		if(ref == null && event.getType() == ServiceEvent.REGISTERED) {
			ref = event.getServiceReference();
			log = (LogService) context.getService(ref);
			// ask the component manager to check the component instance state
			manager.checkInstanceState();
		}
		if(ref != null && event.getType() == ServiceEvent.UNREGISTERING && ref == event.getServiceReference()) {
			//The log service goes away
			log = null;
			context.ungetService(ref);
			ref = context.getServiceReference(LogService.class.getName());
			if(ref != null) { log = (LogService) context.getService(ref); }
			else { manager.checkInstanceState(); }
		}
	}



	
	

	
}

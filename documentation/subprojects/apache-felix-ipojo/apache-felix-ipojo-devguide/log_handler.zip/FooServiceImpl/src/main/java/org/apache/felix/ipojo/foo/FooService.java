package org.apache.felix.ipojo.foo;

public interface FooService {
	
	void foo();

}

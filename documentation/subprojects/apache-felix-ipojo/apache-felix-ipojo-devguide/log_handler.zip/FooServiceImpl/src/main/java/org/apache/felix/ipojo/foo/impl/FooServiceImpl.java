package org.apache.felix.ipojo.foo.impl;

import org.apache.felix.ipojo.foo.FooService;

public class FooServiceImpl implements FooService {

	public void foo() {
		System.out.println("Foo");
	}
	

}

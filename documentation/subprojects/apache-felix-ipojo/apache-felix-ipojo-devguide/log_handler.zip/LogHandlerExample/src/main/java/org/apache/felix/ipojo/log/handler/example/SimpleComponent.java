package org.apache.felix.ipojo.log.handler.example;

import org.apache.felix.ipojo.foo.FooService;

public class SimpleComponent {
	
	FooService fs;
	
	public SimpleComponent() {}

}

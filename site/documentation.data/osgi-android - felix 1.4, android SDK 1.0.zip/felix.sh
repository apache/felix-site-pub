#/bin/sh
/system/bin/dalvikvm -Xbootclasspath:/system/framework/core.jar -classpath bin/felix.jar org.apache.felix.main.Main

package ipojo.example.hello;
public interface Hello {
/**
   * Return a message like: "Hello $user_name"
   * @param name: the name of the user
   * @return the hello message
 **/
public String sayHello(String name);
}
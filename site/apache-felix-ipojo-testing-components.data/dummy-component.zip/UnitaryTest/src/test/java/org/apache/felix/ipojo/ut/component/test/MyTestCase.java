package org.apache.felix.ipojo.ut.component.test;

import junit.framework.TestCase;

import org.apache.felix.ipojo.ut.component.DummyComponent;
import org.easymock.MockControl;
import org.osgi.service.log.LogService;

public class MyTestCase extends TestCase {
    
    private DummyComponent component;
    
    private MockControl control;
    private LogService mock;
    
    /**
     * Method executed before test methods.
     * @see junit.framework.TestCase#setUp()
     */
    public void setUp() {
        // Creates a mock object for replace the log service.
        control = MockControl.createControl(LogService.class); 
        mock = (LogService) control.getMock();

        // Creates an instance of the component.
        component = new DummyComponent(mock);
    }
    
    /**
     * Checks the behavior of the
     * {@link DummyComponent#doSomething()}
     * method.
     */
    public void testDoSomething() {
        int result; 
        result = component.doSomething();
        assertEquals("Check result 1", 1, result);
        result = component.doSomething();
        assertEquals("Check result 2", 2, result);
        result = component.doSomething();
        assertEquals("Check result 3", 3, result);
    }

}
